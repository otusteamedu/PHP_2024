INSERT INTO public.film_attributes (id, type_id, name) VALUES (1, 1, 'Рецензии критиков');
INSERT INTO public.film_attributes (id, type_id, name) VALUES (2, 1, 'Отзыв киноакадемии');
INSERT INTO public.film_attributes (id, type_id, name) VALUES (3, 2, 'Оскар');
INSERT INTO public.film_attributes (id, type_id, name) VALUES (4, 2, 'Ника');
INSERT INTO public.film_attributes (id, type_id, name) VALUES (5, 3, 'Мировая премьера');
INSERT INTO public.film_attributes (id, type_id, name) VALUES (6, 3, 'Премьера в РФ');
INSERT INTO public.film_attributes (id, type_id, name) VALUES (7, 4, 'Начало продажи билетов');
INSERT INTO public.film_attributes (id, type_id, name) VALUES (8, 4, 'Начало рекламы на ТВ');
INSERT INTO public.film_attributes (id, type_id, name) VALUES (9, 4, 'Начало показа');
