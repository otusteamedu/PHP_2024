INSERT INTO public.film_attribute_types (id, name, type) VALUES (2, 'Премия', 'boolean');
INSERT INTO public.film_attribute_types (id, name, type) VALUES (1, 'Рецензии', 'string');
INSERT INTO public.film_attribute_types (id, name, type) VALUES (3, 'Важные даты', 'date');
INSERT INTO public.film_attribute_types (id, name, type) VALUES (4, 'Служебные даты', 'date');
